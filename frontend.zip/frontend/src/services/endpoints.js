export const endpoints = {
  clientes: "clientes/",
  conceptos: "conceptos/",
  reglas: "reglas/",
  bolsas: "bolsas/",
  usos: "usos/",
  cargarPuntos: "cargar_puntos/",
  usarPuntos: "usar_puntos/",
  consultaClientes: "consulta_clientes/",
  consultaBolsas: "consulta_bolsas/",
  consultaUsos: "consulta_uso_puntos/",
};
